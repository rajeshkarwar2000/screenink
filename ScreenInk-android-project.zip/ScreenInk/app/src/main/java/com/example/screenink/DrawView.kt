package com.example.screenink

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

enum class Tool { PEN, HIGHLIGHTER, BRUSH, LASER, ERASER }

class DrawView(c: Context) : View(c) {
    var tool = Tool.LASER
    var color = Color.RED
    private class Stroke(val path: Path, val paint: Paint)
    private class Pt(val x: Float, val y: Float, val t: Long)
    private val strokes = ArrayList<Stroke>()
    private var cur: Stroke? = null
    private val trail = ArrayList<Pt>()
    private var laserDown = false
    private val laserFadeMs = 700L
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun strokePaint(pressure: Float = 1f) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        when (tool) {
            Tool.PEN -> { this.color = this@DrawView.color; strokeWidth = 5f }
            Tool.BRUSH -> { this.color = this@DrawView.color; strokeWidth = 18f; alpha = 200 }
            Tool.HIGHLIGHTER -> { this.color = this@DrawView.color; alpha = 90; strokeWidth = 36f; strokeCap = Paint.Cap.SQUARE }
            Tool.ERASER -> { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR); strokeWidth = 50f }
            else -> {}
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x; val y = e.y
        if (tool == Tool.LASER) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { laserDown = true; trail.add(Pt(x, y, now())) }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until e.historySize) trail.add(Pt(e.getHistoricalX(i), e.getHistoricalY(i), now()))
                    trail.add(Pt(x, y, now()))
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> laserDown = false
            }
            postInvalidateOnAnimation(); return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { cur = Stroke(Path().apply { moveTo(x, y); lineTo(x + .1f, y) }, strokePaint()); strokes.add(cur!!) }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.historySize) cur?.path?.lineTo(e.getHistoricalX(i), e.getHistoricalY(i))
                cur?.path?.lineTo(x, y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> cur = null
        }
        invalidate(); return true
    }

    private fun now() = System.currentTimeMillis()

    override fun onDraw(cv: Canvas) {
        val layer = cv.saveLayer(null, null)
        strokes.forEach { cv.drawPath(it.path, it.paint) }
        cv.restoreToCount(layer)
        val t = now()
        trail.removeAll { t - it.t > laserFadeMs && !laserDown }
        if (trail.isNotEmpty()) {
            for (i in 1 until trail.size) {
                val a = trail[i - 1]; val b = trail[i]
                val f = (1f - (t - b.t).toFloat() / laserFadeMs).coerceIn(0f, 1f)
                glow.apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.RED; alpha = (90 * f).toInt(); strokeWidth = 26f * f + 6 }
                cv.drawLine(a.x, a.y, b.x, b.y, glow)
                glow.apply { color = Color.rgb(255, 80, 80); alpha = (255 * f).toInt(); strokeWidth = 9f * f + 2 }
                cv.drawLine(a.x, a.y, b.x, b.y, glow)
            }
            if (laserDown) trail.last().let { p ->
                dot.color = Color.RED; dot.alpha = 80; cv.drawCircle(p.x, p.y, 34f, dot)
                dot.color = Color.RED; dot.alpha = 255; cv.drawCircle(p.x, p.y, 16f, dot)
                dot.color = Color.WHITE; cv.drawCircle(p.x, p.y, 6f, dot)
            }
            postInvalidateOnAnimation()
        }
    }

    fun undo() { if (strokes.isNotEmpty()) { strokes.removeAt(strokes.size - 1); invalidate() } }
    fun clearAll() { strokes.clear(); trail.clear(); invalidate() }
}
