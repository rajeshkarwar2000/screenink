package com.example.screenink

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var draw: DrawView
    private lateinit var bar: LinearLayout
    private lateinit var drawLp: WindowManager.LayoutParams
    private var drawing = true
    private val palette = intArrayOf(Color.RED, Color.BLUE, Color.rgb(0, 160, 0), Color.BLACK, Color.rgb(255, 200, 0), Color.MAGENTA)
    private var ci = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "ink"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "ScreenInk", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, ch).setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("ScreenInk is running").addAction(Notification.Action.Builder(null, "Stop", stop).build()).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        draw = DrawView(this)
        drawLp = WindowManager.LayoutParams(-1, -1, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        wm.addView(draw, drawLp)

        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.argb(230, 30, 30, 30)); setPadding(8, 8, 8, 8)
        }
        fun btn(label: String, onClick: (Button) -> Unit) = Button(this).apply {
            text = label; textSize = 12f; isAllCaps = false; setOnClickListener { onClick(this) }
            bar.addView(this, LinearLayout.LayoutParams(190, 110))
        }
        val toolBtns = ArrayList<Pair<Button, Tool>>()
        fun pick(t: Tool) { draw.tool = t; if (!drawing) setDrawing(true); toolBtns.forEach { (b, bt) -> b.alpha = if (bt == t) 1f else .55f } }
        listOf("Laser" to Tool.LASER, "Pen" to Tool.PEN, "Brush" to Tool.BRUSH, "Highlight" to Tool.HIGHLIGHTER, "Eraser" to Tool.ERASER)
            .forEach { (n, t) -> toolBtns.add(btn(n) { pick(t) } to t) }
        btn("Color") { ci = (ci + 1) % palette.size; draw.color = palette[ci]; it.setTextColor(palette[ci]) }
        btn("Undo") { draw.undo() }
        btn("Clear") { draw.clearAll() }
        btn("Use app") { b -> setDrawing(!drawing); b.text = if (drawing) "Use app" else "Draw" }
        btn("Close") { stopSelf() }
        pick(Tool.LASER)

        val barLp = WindowManager.LayoutParams(-2, -2, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        barLp.gravity = Gravity.TOP or Gravity.START; barLp.x = 0; barLp.y = 120
        wm.addView(bar, barLp)

        // drag the toolbar by touching its padding / between buttons
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = barLp.x; oy = barLp.y }
                MotionEvent.ACTION_MOVE -> { barLp.x = ox + (e.rawX - sx).toInt(); barLp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(bar, barLp) }
            }; true
        }
    }

    // drawing=true: overlay captures touches. false: touches pass through to the app underneath.
    private fun setDrawing(on: Boolean) {
        drawing = on
        drawLp.flags = if (on) drawLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else drawLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(draw, drawLp)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") stopSelf(); return START_STICKY
    }

    override fun onDestroy() {
        runCatching { wm.removeView(draw) }; runCatching { wm.removeView(bar) }
        super.onDestroy()
    }
}
